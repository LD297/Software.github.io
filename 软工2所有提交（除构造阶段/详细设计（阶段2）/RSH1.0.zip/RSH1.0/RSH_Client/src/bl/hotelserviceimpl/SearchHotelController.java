package bl.hotelserviceimpl;

import java.util.ArrayList;

import bl.hotelservice.*;
import constant.*;
import vo.*;

public class SearchHotelController implements SearchHotelService {

	@Override
	public ArrayList<HotelVO> getHotelList(String address, String businessArea) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<HotelVO> sort(SortBy sortBy, SortMethod sortM) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<HotelVO> select(SelectConditionVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HotelVO getHotelInfo(String id) {
		// TODO Auto-generated method stub
		return null;
	}

}
