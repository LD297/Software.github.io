package bl.hotelserviceimpl;

import java.util.ArrayList;

import constant.ResultMessage;
import vo.RoomVO;

public class RoomManager {
	public ArrayList<RoomVO> getRoomList() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public ResultMessage updateRoomList(ArrayList<RoomVO> roomList) {
		// TODO Auto-generated method stub
		return null;
	}
}
