package bl.hotelserviceimpl;

import bl.orderservice.CommentService;
import constant.ResultMessage;

public class CommentImpl implements CommentService{

	public static ResultMessage addComment(String id, String userID, String comment){
		// TODO
		return null;
		
	}

	@Override
	public ResultMessage updateGrade(double grade) {
		// TODO Auto-generated method stub
		return null;
	}
}
