package bl.hotelserviceimpl;

import constant.ResultMessage;
import po.HotelStaffPO;

public class WMHotel{

	public int getHotelNum(String address) {
		// TODO Auto-generated method stub
		return 0;
	}

	public ResultMessage addHotel(String id, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage deleteHotel(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public ResultMessage updateHotelStaff(HotelStaffPO po) {
		// TODO Auto-generated method stub
		return null;
	}

}
