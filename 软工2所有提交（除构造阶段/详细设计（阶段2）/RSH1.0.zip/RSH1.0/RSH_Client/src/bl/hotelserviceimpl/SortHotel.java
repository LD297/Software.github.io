package bl.hotelserviceimpl;

import java.util.ArrayList;

import constant.SortBy;
import constant.SortMethod;
import vo.HotelVO;

public class SortHotel {
	public ArrayList<HotelVO> sort(SortBy sortBy, SortMethod sortM) {
		// TODO Auto-generated method stub
		return null;
	}
}
