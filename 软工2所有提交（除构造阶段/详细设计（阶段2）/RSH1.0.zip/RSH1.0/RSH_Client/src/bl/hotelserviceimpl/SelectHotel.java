package bl.hotelserviceimpl;

import java.util.ArrayList;

import vo.HotelVO;
import vo.SelectConditionVO;

public class SelectHotel{
	public ArrayList<HotelVO> select(SelectConditionVO vo) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
