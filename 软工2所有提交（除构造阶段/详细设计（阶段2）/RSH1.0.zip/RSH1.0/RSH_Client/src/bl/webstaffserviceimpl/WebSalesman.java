package bl.webstaffserviceimpl;

import constant.ResultMessage;

public class WebSalesman {

	String ID;
	String password;
	String district;
	
	public WebSalesman(String id, String passw) {
		// TODO Auto-generated constructor stub
		ID=id;
		password=passw;
	}
	
	public static boolean getInstace(String id){
		
		return false;
	}
	
	public ResultMessage update(){
		
		return null;
	}

}
