package bl.promotionServiceimpl;

/**
 * 优惠策略的适用范围
 * @author aa
 *
 */
public class Scope {

	/**
	 * 测试是否符合适用范围要求
	 * @param scope
	 * @return
	 */
	public boolean check(String scope){
		boolean result=false;
		
		return result;
	}
}
