package bl.promotionServiceimpl;

/**
 * 减额优惠
 * @author aa
 *
 */
public class ReducePromotion extends PromotionType{

	public int getPromotion(int total){
		
		return total;
	}
	
}
