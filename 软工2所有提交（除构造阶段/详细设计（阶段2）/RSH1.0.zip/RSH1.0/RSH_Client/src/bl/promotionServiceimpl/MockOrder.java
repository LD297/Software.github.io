package bl.promotionServiceimpl;

public class MockOrder {

}
