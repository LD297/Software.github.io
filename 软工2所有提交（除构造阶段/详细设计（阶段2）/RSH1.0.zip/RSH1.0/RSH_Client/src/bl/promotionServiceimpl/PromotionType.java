package bl.promotionServiceimpl;

/**
 * 优惠的种类
 * @author aa
 *
 */
public class PromotionType  {

	public int getPromotion(int total){
		
		return total;
	}
}
