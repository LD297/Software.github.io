package bl.promotionServiceimpl;

/**
 * 生日要求
 * @author aa
 *
 */
public class BirthdayCondition extends ConditionType{

	public BirthdayCondition(){
		
	}
	
	/*
	 * (non-Javadoc)
	 * @see service.promotioinserviceimpl.ConditionType#check(int)
	 */
	public boolean check(int isBirthday){
		boolean result=false;
		
		return result;
	}


}
