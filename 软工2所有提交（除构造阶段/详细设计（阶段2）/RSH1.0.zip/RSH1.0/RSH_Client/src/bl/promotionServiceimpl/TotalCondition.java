package bl.promotionServiceimpl;

/**
 * 总额要求
 * @author aa
 *
 */
public class TotalCondition extends ConditionType{

	int total;
	
	public TotalCondition(int t){
		total=t;
	}
	
	public boolean check(int t){
		boolean result = false;
		
		return result;
	}
}
