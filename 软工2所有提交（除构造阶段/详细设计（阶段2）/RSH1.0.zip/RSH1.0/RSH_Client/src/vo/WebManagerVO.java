package vo;

public class WebManagerVO {

}
