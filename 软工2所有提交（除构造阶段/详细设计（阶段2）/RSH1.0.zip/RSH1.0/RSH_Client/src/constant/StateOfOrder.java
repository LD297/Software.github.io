package constant;

public enum StateOfOrder {
	unexecuted,
	executed,
	abnormal,
	canceled

}
