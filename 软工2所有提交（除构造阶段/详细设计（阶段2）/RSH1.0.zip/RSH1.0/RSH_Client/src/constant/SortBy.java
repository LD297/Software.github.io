package constant;

public enum SortBy {
	grade,level,price
}
