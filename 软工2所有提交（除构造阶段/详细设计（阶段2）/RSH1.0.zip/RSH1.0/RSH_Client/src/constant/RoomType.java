package constant;

public enum RoomType {

	singleRoom,
	doubleRoom;
}
