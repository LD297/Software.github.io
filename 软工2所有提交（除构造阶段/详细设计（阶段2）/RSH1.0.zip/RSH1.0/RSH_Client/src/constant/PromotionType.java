package constant;

public enum PromotionType {

}
