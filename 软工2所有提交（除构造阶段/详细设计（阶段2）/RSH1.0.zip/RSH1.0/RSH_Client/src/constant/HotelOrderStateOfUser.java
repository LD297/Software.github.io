package constant;

public enum HotelOrderStateOfUser {
	normal,abnormal,cancel,unexecuted
}
