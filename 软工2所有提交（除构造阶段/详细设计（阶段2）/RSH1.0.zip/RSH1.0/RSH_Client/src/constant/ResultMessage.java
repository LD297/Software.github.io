package constant;

public enum ResultMessage {
	error,
	pass,
	successfullyLogout,
	succeed,
failure,
exists,
not_exosts,
success,
not_success;
}
