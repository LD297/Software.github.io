package constant;

public enum ConditionType {

}
