package data.daoimpl.userdaoimpl;

import java.rmi.RemoteException;
import java.util.ArrayList;

import constant.ResultMessage;
import data.dao.userdao.CreditRecordListDao;
import po.CreditRecordPO;

public class CreditRecordListDaoImpl implements CreditRecordListDao{

	@Override
	public ArrayList<CreditRecordPO> getCreditRecordList() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResultMessage addCreditRecord(CreditRecordPO po) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

}
